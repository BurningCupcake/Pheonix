import UIKit

struct EyeMovements {
    let position: CGPoint
}

