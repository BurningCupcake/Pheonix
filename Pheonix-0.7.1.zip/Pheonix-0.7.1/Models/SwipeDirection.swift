import Foundation

enum SwipeDirection {
    case left
    case right
    case up
    case down
}
